import { useState } from "react";
import Link from "next/link";

export default function LoginForm() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
  
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
  
      const data = await res.json();
  
      if (!res.ok) {
        setError(data.error || "Errore nel login");
      } else {
        // Reindirizza all'area privata
        window.location.href = "/area-privata";
      }
    } catch (err) {
      console.error(err);
      setError("Errore imprevisto");
    }
  };
  

  return (
    <>
    <form onSubmit={handleSubmit} className="max-w-md mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">Login</h2>

      <label className="block mb-2">
        Username
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="mt-1 block w-full border rounded p-2"
          required
        />
      </label>

      <label className="block mb-4">
        Password
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mt-1 block w-full border rounded p-2"
          required
        />
      </label>

      {error && <p className="text-red-600 mb-4">{error}</p>}

      <button
        type="submit"
        className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700"
      >
        Accedi
      </button>
    </form>
    <p className="mt-4 text-center text-sm text-gray-600">
        Non hai un account?{" "}
        <Link href="/register" className="text-blue-600 hover:underline">
          Registrati
        </Link>
      </p>
    </>
    
  );
}
