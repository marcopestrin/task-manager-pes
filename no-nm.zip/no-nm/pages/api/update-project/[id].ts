import { NextApiRequest, NextApiResponse } from 'next';
import jwt from 'jsonwebtoken';
import cookie from 'cookie';
import { prisma } from '../../../lib/db';

const JWT_SECRET = process.env.JWT_SECRET || 'tua-chiave-segreta';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {

  if (req.method !== 'PUT') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const { id } = req.query;

  const cookies = req.headers.cookie;
  if (!cookies) {
    return res.status(401).json({ message: 'Non autorizzato' });
  }

  const parsed = cookie.parse(cookies);
  const token = parsed.token;

  if (!token) {
    return res.status(401).json({ message: 'Token mancante' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const { name, description, userIds } = req.body;

    if (!name || typeof name !== 'string') {
      return res.status(400).json({ message: 'Nome non valido' });
    }

    if (!Array.isArray(userIds)) {
      return res.status(400).json({ message: 'Lista utenti non valida' });
    }

    // Verifica che il progetto esista e sia di proprietà dell'utente autenticato
    const project = await prisma.project.findUnique({
      where: { id: id as string }
    });

    if (!project || project.ownerId !== decoded.userId) {
      return res.status(403).json({ message: 'Accesso negato' });
    }


    await prisma.project.update({
      where: { id: id as string },
      data: {
        name,
        description,
      },
    });
    
    // Pulisci i vecchi legami ProjectUser
    await prisma.projectUser.deleteMany({
      where: { projectId: id as string },
    });
    
    // Inserisci i nuovi legami ProjectUser
    if (userIds.length > 0) {
      await prisma.projectUser.createMany({
        data: userIds.map(userId => ({
          projectId: id as string,
          userId,
        })),
      });
    }

    const updatedProject = await prisma.project.findUnique({
      where: { id: id as string },
      select: {
        id: true,
        name: true,
        description: true,
        projectCode: true,
        users: {
          select: {
            user: {
              select: {
                id: true,
                username: true,
              }
            }
          }
        }
      }
    });


    res.status(200).json({
      updatedProject
    });
  } catch (err) {
    console.error('[UPDATE PROJECT ERROR]', err);
    res.status(500).json({ message: 'Errore interno del server' });
  }
}
