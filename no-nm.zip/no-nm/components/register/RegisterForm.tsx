import { useState } from "react";
import Link from "next/link";


export default function RegisterForm() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError("Le password non coincidono");
      return;
    }
  
    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
  
      const data = await res.json();
  
      if (!res.ok) {
        setError(data.error || "Errore nella registrazione");
      } else {
        setError("");
        alert("Registrazione completata!");
        setUsername("");
        setPassword("");
        setConfirmPassword("");
        // after registration redirect to login page
        window.location.href = '/login';
      }
    } catch (err) {
      console.error(err);
      setError("Errore imprevisto");
    }
  };
  

  return (
    <>
    <form onSubmit={handleSubmit} className="max-w-md mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">Registrati</h2>

      <label className="block mb-2">
        Username
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="mt-1 block w-full border rounded p-2"
          required
        />
      </label>

      <label className="block mb-2">
        Password
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mt-1 block w-full border rounded p-2"
          required
        />
      </label>

      <label className="block mb-4">
        Conferma Password
        <input
          type="password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          className="mt-1 block w-full border rounded p-2"
          required
        />
      </label>

      {error && <p className="text-red-600 mb-4">{error}</p>}

      <button
        type="submit"
        className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
      >
        Registrati
      </button>
    </form>
    <p className="mt-4 text-center text-sm text-gray-600">
        Hai già un account?{" "}
        <Link href="/login" className="text-blue-600 hover:underline">
          Accedi
        </Link>
      </p>
    </>
  );
}
