import { GetServerSidePropsContext } from 'next';
import cookie from 'cookie';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'tua-chiave-segreta';

export async function redirectIfAuthenticated(context: GetServerSidePropsContext) {
  const currentPath = context.resolvedUrl;
  if (currentPath.startsWith('/edit-project')) {
    return { props: {} };
  }
  
  const cookies = context.req.headers.cookie;

  if (!cookies) return { props: {} };

  const parsed = cookie.parse(cookies);
  const token = parsed.token;

  if (!token) return { props: {} };

  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    // Se il token è valido, redirige all'area privata
    return {
      redirect: {
        destination: '/area-privata',
        permanent: false,
      },
    };
  } catch (err) {
    // Token non valido o scaduto → rimane nella pagina pubblica
    return { props: {} };
  }
}

interface AuthenticatedResult {
  user: any; 
}

/**
 * Controlla che l'utente sia autenticato.
 * Se sì, restituisce l'utente decodificato.
 * Altrimenti, reindirizza al login.
 */
export async function requireAuthentication(
  context: GetServerSidePropsContext
): Promise<{ redirect: { destination: string; permanent: false } } | AuthenticatedResult> {
  const cookies = context.req.headers.cookie;
  if (!cookies) {
    return {
      redirect: {
        destination: '/login',
        permanent: false,
      },
    };
  }

  const parsed = cookie.parse(cookies);
  const token = parsed.token;

  if (!token) {
    return {
      redirect: {
        destination: '/login',
        permanent: false,
      },
    };
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return { user: decoded };
  } catch (err) {
    return {
      redirect: {
        destination: '/login',
        permanent: false,
      },
    };
  }
}
