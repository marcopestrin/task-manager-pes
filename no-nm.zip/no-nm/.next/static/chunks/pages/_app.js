__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_4f3d469a._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__fb6a6365._.js",
  "static/chunks/styles_globals_79636149.css",
  "static/chunks/pages__app_5771e187._.js",
  "static/chunks/pages__app_7132be12._.js"
])
