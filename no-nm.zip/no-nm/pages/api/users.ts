// pages/api/users.ts
import { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '../../lib/db';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { query } = req.query;
  const users = await prisma.user.findMany({
    where: {
      OR: [
        { username: { contains: query as string, mode: 'insensitive' } },
      ],
    },
    select: {
      id: true,
      username: true,
    },
  });
  res.status(200).json(users);
}
