import '../styles/globals.css';
import type { AppProps } from 'next/app';

export default function MyApp({ Component, pageProps }: AppProps) {
  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <Component {...pageProps} />
    </main>
  );
}
