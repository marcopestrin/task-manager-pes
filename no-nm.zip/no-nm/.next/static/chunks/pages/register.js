__turbopack_load_page_chunks__("/register", [
  "static/chunks/node_modules_next_dist_4f3d469a._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__613b41d3._.js",
  "static/chunks/pages_edit-project_[id]_tsx_5771e187._.js",
  "static/chunks/pages_edit-project_[id]_tsx_abe5f6aa._.js"
])
