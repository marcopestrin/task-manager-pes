__turbopack_load_page_chunks__("/api/register", [
  "static/chunks/node_modules_next_dist_4f3d469a._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__8e73b2e6._.js",
  "static/chunks/pages_area-privata_5771e187._.js",
  "static/chunks/pages_area-privata_a3b9f2c6._.js"
])
