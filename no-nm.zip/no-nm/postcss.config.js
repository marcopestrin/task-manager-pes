module.exports = {
  plugins: {
    autoprefixer: {},
    '@tailwindcss/postcss': {},

  },
};
