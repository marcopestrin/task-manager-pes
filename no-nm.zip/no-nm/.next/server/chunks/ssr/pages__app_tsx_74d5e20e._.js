module.exports = {

"[project]/pages/_app.tsx [ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=pages__app_tsx_74d5e20e._.js.map