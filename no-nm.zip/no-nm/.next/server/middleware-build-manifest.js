globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/node_modules_next_dist_4f3d469a._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__fb6a6365._.js",
      "static/chunks/styles_globals_79636149.css",
      "static/chunks/pages__app_5771e187._.js",
      "static/chunks/pages__app_7132be12._.js"
    ],
    "/area-privata": [
      "static/chunks/node_modules_next_9a882e92._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__8e73b2e6._.js",
      "static/chunks/pages_area-privata_5771e187._.js",
      "static/chunks/pages_area-privata_0f1df311._.js"
    ],
    "/edit-project/[id]": [
      "static/chunks/node_modules_next_dist_4f3d469a._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__613b41d3._.js",
      "static/chunks/pages_edit-project_[id]_tsx_5771e187._.js",
      "static/chunks/pages_edit-project_[id]_tsx_abe5f6aa._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];