import { useState } from 'react';
import { GetServerSideProps } from 'next';
import jwt from 'jsonwebtoken';
import cookie from 'cookie';
import { PrismaClient } from '@prisma/client';
import Link from 'next/link';

import { requireAuthentication } from '../lib/auth';


const prisma = new PrismaClient();

const JWT_SECRET = process.env.JWT_SECRET || 'tua-chiave-segreta';


export const getServerSideProps: GetServerSideProps = async (context) => {
  const auth = await requireAuthentication(context);
  if ('redirect' in auth) return auth;

  const cookies = context.req.headers.cookie;
  const parsed = cookie.parse(cookies);
  const token = parsed.token;


  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    const projects = await prisma.project.findMany({
      where: {
        ownerId: decoded.userId,
      },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        description: true,
        projectCode: true,
      },
    });
    return { 
      props: {
        user: decoded,
        projects
      }
    };
  } catch (err) {
    return { 
      redirect: { 
        destination: '/login', 
        permanent: false 
      }
    };
  }
};

export default function AreaPrivata({ user, projects }: any) {
  const [projectList, setProjectList] = useState(projects || []);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDescription, setNewProjectDescription] = useState('');
  const [loading, setLoading] = useState(false);

  if (!user) return <p>Accesso non autorizzato</p>;

  const handleLogout = async () => {
    try {
      const res = await fetch('/api/logout', {
        method: 'POST',
      });

      if (res.ok) {
        // Logout success
        window.location.href = '/login';
      } else {
        alert('Errore durante il logout');
      }
    } catch (error) {
      alert('Errore di rete durante il logout');
      console.error(error);
    }
  };

  const handleAddProject = async () => {
    if (!newProjectName.trim()) {
      alert('Inserisci un nome per il progetto');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/create-project', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newProjectName,
          description: newProjectDescription,
        }),
      });

      if (res.ok) {
        const newProject = await res.json();
        setProjectList([newProject, ...projectList]);
        setNewProjectName('');
        setNewProjectDescription('');
      } else {
        alert('Errore nella creazione del progetto');
      }
    } catch (error) {
      alert('Errore di rete');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10">
      <h1 className="text-2xl font-bold">Benvenuto, {user.username}!</h1>
      <p className="mt-2">Questa è l'area riservata.</p>

      <div className="mt-6">
        <h2 className="text-xl font-semibold">I tuoi progetti</h2>
        {projectList.length === 0 && <p>Nessun progetto creato.</p>}
        <ul className="mt-2 space-y-2">
          {projectList.map((p: any) => (
            <li key={p.id} className="border p-2 rounded">
              <Link href={`/edit-project/${p.id}`}>
                <div className="cursor-pointer">
                  <strong>{p.name}</strong>
                  <p>{p.description || 'Nessuna descrizione'}</p>
                  <small>Codice: {p.projectCode}</small>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-6">
        <h2 className="text-xl font-semibold">Crea un nuovo progetto</h2>
        <input
          type="text"
          placeholder="Nome progetto"
          value={newProjectName}
          onChange={(e) => setNewProjectName(e.target.value)}
          className="border p-2 w-full mt-1 rounded"
        />
        <textarea
          placeholder="Descrizione (opzionale)"
          value={newProjectDescription}
          onChange={(e) => setNewProjectDescription(e.target.value)}
          className="border p-2 w-full mt-2 rounded"
          rows={3}
        />
        <button
          onClick={handleAddProject}
          disabled={loading}
          className="mt-3 bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {loading ? 'Creando...' : 'Aggiungi Progetto'}
        </button>
      </div>

      <button
        onClick={handleLogout}
        className="mt-8 bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700"
      >
        Logout
      </button>
    </div>
  );
}
