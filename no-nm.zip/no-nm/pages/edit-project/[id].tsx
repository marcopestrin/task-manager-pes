import { useState, useEffect } from 'react';

import { GetServerSideProps } from 'next';
import jwt from 'jsonwebtoken';
import cookie from 'cookie';
import { prisma } from '../../lib/db';
import { requireAuthentication } from '../../lib/auth';

const JWT_SECRET = process.env.JWT_SECRET || 'tua-chiave-segreta';

export const getServerSideProps: GetServerSideProps = async (context) => {
  const auth = await requireAuthentication(context);
  if ('redirect' in auth) return auth;

  const { id } = context.params!;
  const cookies = context.req.headers.cookie;
  
  if (!cookies) return { redirect: { destination: '/login', permanent: false } };

  const parsed = cookie.parse(cookies);
  const token = parsed.token;
  
  if (!token) return { redirect: { destination: '/login', permanent: false } };

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;

    const project = await prisma.project.findUnique({
      where: { id: id as string },
      include: {
        users: {
          select: {
            userId: true,
            user: {
              select: {
                id: true,
                username: true,
              },
            },
          },
        },
      },
    });

    if (!project || project.ownerId !== decoded.userId) {
      return { redirect: { destination: '/area-privata', permanent: false } };
    }

    const usersList = await prisma.user.findMany({
      select: {
        id: true,
        username: true,
      },
    });

    return {
      props: {
        project: {
          ...project,
          createdAt: project.createdAt.toISOString(),
          updatedAt: project.updatedAt.toISOString(),
        },
        usersList,
      },
    };
  } catch (err) {
    console.error(err);
    return { redirect: { destination: '/login', permanent: false } };
  }
};

export default function EditProject({ project, usersList }: any) {
  const [name, setName] = useState(project.name);
  const [description, setDescription] = useState(project.description || '');
  const [selectedUsers, setSelectedUsers] = useState<string[]>(
    project.users ? project.users.map((u: any) => u.userId) : []
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredUsers, setFilteredUsers] = useState(usersList || []);
  const [saving, setSaving] = useState(false);

    // Filtra gli utenti per la ricerca
    useEffect(() => {
      if (!searchTerm) {
        setFilteredUsers(usersList);
        return;
      }
      const filtered = usersList.filter((user: any) =>
        user.username.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredUsers(filtered);
    }, [searchTerm, usersList]);


  const handleSave = async () => {
    setSaving(true);

    const res = await fetch(`/api/update-project/${project.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        description,
        userIds: selectedUsers
      }),
    });

    if (res.ok) {
      alert('Progetto aggiornato');
      window.location.href = '/area-privata';
    } else {
      alert('Errore durante il salvataggio');
    }

    setSaving(false);
  };

    // Toggle selezione utente
    const toggleUser = (userId: string) => {
      if (selectedUsers.includes(userId)) {
        setSelectedUsers(selectedUsers.filter(id => id !== userId));
      } else {
        setSelectedUsers([...selectedUsers, userId]);
      }
    };

  return (
    <div className="max-w-md mx-auto mt-10">
      <h1 className="text-2xl font-bold">Modifica progetto</h1>

      <div className="mt-4">
        <label className="block text-sm font-medium">Nome</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="border p-2 w-full rounded"
        />
      </div>

      <div className="mt-4">
        <label className="block text-sm font-medium">Descrizione</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={4}
          className="border p-2 w-full rounded"
        />
      </div>
      <div className="max-h-40 overflow-auto border rounded p-2">
          {filteredUsers.length === 0 && <p>Nessun utente trovato</p>}
          {filteredUsers.map((user: any) => (
            <div key={user.id} className="flex items-center space-x-2 mb-1">
              <input
                type="checkbox"
                checked={selectedUsers.includes(user.id)}
                onChange={() => toggleUser(user.id)}
              />
              <span>{user.username} </span>
            </div>
          ))}
        </div>
      <button
        onClick={handleSave}
        disabled={saving}
        className="mt-4 bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 disabled:opacity-50"
      >
        {saving ? 'Salvando...' : 'Salva modifiche'}
      </button>
    </div>
  );
}
